# 🎨 Algorithm Visualizer - Sorting Algorithms

An elegant, interactive web application that visualizes how different sorting algorithms work through smooth animations and step-by-step explanations.

![Algorithm Visualizer](https://img.shields.io/badge/React-18.2.0-blue) ![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.3.5-38B2AC) ![Framer Motion](https://img.shields.io/badge/Framer%20Motion-10.16.4-FF0055)

## ✨ Features

### 🔢 Supported Algorithms
- **Bubble Sort** - O(n²) time complexity
- **Selection Sort** - O(n²) time complexity
- **Insertion Sort** - O(n²) time complexity
- **Merge Sort** - O(n log n) time complexity
- **Quick Sort** - O(n log n) average time complexity

### 🎯 Core Capabilities
- **Live Visualization**: Watch bars animate in real-time as elements are compared and swapped
- **Custom Arrays**: Input your own comma-separated values to sort
- **Random Generation**: Create arrays of varying sizes (5-100 elements)
- **Speed Control**: Adjust animation speed from 1% to 100%
- **Pause/Resume**: Full playback control during sorting
- **Sound Effects**: Optional audio feedback for swaps and comparisons
- **Theme Toggle**: Switch between dark and light themes
- **Educational Display**: View current step descriptions and complexity analysis

### 🎨 Design Features
- Refined, elegant UI with custom typography (Crimson Pro + Space Mono)
- Smooth animations powered by Framer Motion
- Responsive layout that works on mobile, tablet, and desktop
- Color-coded visualization:
  - 🔵 Blue: Unsorted elements
  - 🟡 Yellow: Elements being compared
  - 🔴 Red: Elements being swapped
  - 🟢 Green: Sorted elements

## 🚀 Quick Start

### Prerequisites
- Node.js 16.x or higher
- npm or yarn package manager

### Installation

1. **Extract or navigate to the project directory**
```bash
cd sorting-visualizer
```

2. **Install dependencies**
```bash
npm install
```

3. **Start the development server**
```bash
npm run dev
```

4. **Open your browser**
The app will automatically open at `http://localhost:3000`

### Build for Production
```bash
npm run build
```

The optimized build will be in the `dist` folder.

## 📖 How to Use

### Getting Started
1. **Select an Algorithm**: Choose from the dropdown (Bubble, Selection, Insertion, Merge, or Quick Sort)
2. **Set Up Your Array**:
   - Use the size slider to generate a random array (5-100 elements)
   - OR input custom values: type comma-separated numbers and click "Set"
3. **Adjust Speed**: Use the speed slider to control animation pace
4. **Start Sorting**: Click "Start" to begin the visualization

### During Visualization
- **Pause/Resume**: Pause the animation at any time to study a particular step
- **Reset**: Stop and generate a new random array
- **Current Step**: Read the description to understand what's happening
- **Array Values**: See the numeric values highlighted by their current state

### Settings
- **Sound Effects**: Toggle audio feedback for swaps and comparisons
- **Dark Theme**: Switch between dark and light color schemes

## 🏗️ Project Structure

```
sorting-visualizer/
├── index.html              # HTML entry point
├── main.jsx                # React entry point
├── sorting-visualizer.jsx  # Main application component
├── index.css               # Global styles with Tailwind
├── package.json            # Dependencies and scripts
├── vite.config.js          # Vite configuration
├── tailwind.config.js      # Tailwind CSS configuration
├── postcss.config.js       # PostCSS configuration
└── README.md               # Documentation
```

## 🧩 Architecture

### Component Structure
The application is built as a single, self-contained React component with clear separation of concerns:

**Sorting Algorithms** (Lines 8-196)
- Pure generator functions that yield animation steps
- Each algorithm returns standardized step objects:
  - `{ type: 'compare', indices: [i, j] }`
  - `{ type: 'swap', indices: [i, j], array: [...] }`
  - `{ type: 'overwrite', indices: [i], array: [...] }`
  - `{ type: 'markSorted', index: i }`

**Algorithm Metadata** (Lines 198-228)
- Centralized configuration for algorithm details
- Time and space complexity information
- Educational descriptions

**Visualizer Component** (Lines 230+)
- React hooks for state management
- Animation loop using async/await
- Framer Motion for smooth transitions
- Responsive Tailwind styling

### Key Features Implementation

**Animation System**
```javascript
// Uses generator functions for step-by-step execution
function* bubbleSort(arr) {
  // ... algorithm logic
  yield { type: 'compare', indices: [j, j + 1] };
  yield { type: 'swap', indices: [j, j + 1], array: [...array] };
  // ...
}
```

**State Management**
```javascript
const [array, setArray] = useState([]);           // Current array values
const [comparing, setComparing] = useState([]);   // Indices being compared
const [swapping, setSwapping] = useState([]);     // Indices being swapped
const [sorted, setSorted] = useState([]);         // Sorted indices
```

**Performance Optimization**
- Uses `React.memo` concepts through proper state updates
- Generator functions prevent blocking the main thread
- Framer Motion handles efficient animations
- Array updates are immutable (spread operator)

## 🎓 Educational Value

### Learning Outcomes
Students and developers can:
- **Visualize** how each algorithm processes data
- **Compare** efficiency between different approaches
- **Understand** time and space complexity trade-offs
- **Observe** the step-by-step execution flow

### Algorithm Insights

**Bubble Sort**
- Simple but inefficient for large datasets
- Good for teaching basic sorting concepts
- Notice how larger values "bubble" to the end

**Selection Sort**
- Fewer swaps than bubble sort
- Finds minimum and places it correctly
- Watch the sorted section grow from left

**Insertion Sort**
- Efficient for small or nearly-sorted data
- Builds sorted array incrementally
- See elements shift to make room

**Merge Sort**
- Divide and conquer strategy
- Consistently O(n log n) performance
- Observe the merging of sorted subarrays

**Quick Sort**
- Usually fastest in practice
- Partition-based approach
- Watch pivot selection and partitioning

## 🎨 Customization

### Changing Colors
Edit the `getBarColor` function in `sorting-visualizer.jsx`:
```javascript
const getBarColor = (index) => {
  if (sorted.includes(index)) return 'bg-emerald-500';  // Sorted
  if (swapping.includes(index)) return 'bg-rose-500';   // Swapping
  if (comparing.includes(index)) return 'bg-amber-400'; // Comparing
  return 'bg-slate-400';                                 // Default
};
```

### Adding New Algorithms
1. Create a generator function following the pattern:
```javascript
function* yourSort(arr) {
  const array = [...arr];
  // ... algorithm logic
  yield { type: 'compare', indices: [i, j] };
  yield { type: 'swap', indices: [i, j], array: [...array] };
  return array;
}
```

2. Add to the `ALGORITHMS` object:
```javascript
const ALGORITHMS = {
  // ... existing algorithms
  yourAlgo: {
    name: 'Your Algorithm',
    fn: yourSort,
    timeComplexity: 'O(?)',
    spaceComplexity: 'O(?)',
    description: 'How it works...',
  },
};
```

### Adjusting Animation Timing
Modify the speed calculation in the `startSorting` function:
```javascript
const delay = (101 - speed) * 10; // Current: 10ms to 1000ms range
```

## 🛠️ Technologies Used

- **React 18.2** - Modern UI library with hooks
- **Framer Motion 10.16** - Production-ready animation library
- **Tailwind CSS 3.3** - Utility-first CSS framework
- **Vite 5.0** - Fast build tool and dev server
- **Web Audio API** - Sound effect generation

## 📝 Code Quality

### Best Practices Implemented
- ✅ Functional components with React Hooks
- ✅ Generator functions for algorithm execution
- ✅ Immutable state updates
- ✅ Clear variable naming and comments
- ✅ Separation of concerns (algorithms vs UI)
- ✅ Responsive design patterns
- ✅ Accessibility considerations
- ✅ Performance optimization

### Code Comments
Each algorithm includes:
- Purpose description
- Time complexity analysis
- Space complexity analysis
- Inline comments for complex logic

## 🐛 Troubleshooting

**Issue**: Animations are choppy
- **Solution**: Reduce array size or increase animation speed

**Issue**: Sound doesn't play
- **Solution**: Some browsers require user interaction before playing audio. Try clicking start again.

**Issue**: Custom array not accepting input
- **Solution**: Ensure values are comma-separated numbers between 1-100

**Issue**: Build fails
- **Solution**: Delete `node_modules` and `package-lock.json`, then run `npm install` again

## 🚦 Performance

- Handles arrays up to 100 elements smoothly
- 60 FPS animations on modern browsers
- Optimized re-renders using proper React patterns
- Efficient generator-based algorithm execution

## 📄 License

This project is open source and available for educational purposes.

## 🤝 Contributing

Feel free to fork this project and add:
- New sorting algorithms (Heap Sort, Radix Sort, etc.)
- Additional visualization modes
- More customization options
- Performance improvements

## 📞 Support

For issues or questions:
1. Check the Troubleshooting section
2. Review the code comments
3. Experiment with different settings

---

**Built with ❤️ using React, Framer Motion, and Tailwind CSS**

*Happy Sorting! 🎉*
